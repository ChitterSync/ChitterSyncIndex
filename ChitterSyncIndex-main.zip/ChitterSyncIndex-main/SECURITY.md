# Security Policy

## Supported Versions

This Is A List Of All User Viable Versions (normally one but can multiple if a user requests for a old version or users are using a beta)

| Version | Supported          |
| ------- | ------------------ |
| ALPHA 0.1.358   | :white_check_mark: |


## Reporting a Vulnerability

Report A Vulnerability by Contacting Support, Or DMing any of the main contributors listed below, you can expect us to take action immediately, but you need to list how to replicate the issue, how you discovered it, and any other fine details we could use

@speedevil50 (other Aliases: speed_devil50 - speed_devil50SMg - SMgYT_ - SMg)

@CallMeSirEntertainmentYT

@Landawg99 (other Aliases: Landawg)

@PlaugeDr
