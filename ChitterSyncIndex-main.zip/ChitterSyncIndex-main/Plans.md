visit the landing page and scroll to the bottom, click "trello"
